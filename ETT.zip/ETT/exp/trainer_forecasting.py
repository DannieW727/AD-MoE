import os
import time
import torch
import numpy as np
import torch.nn as nn
from torch.utils.data import DataLoader
import os, csv, math
import torch
import matplotlib.pyplot as plt
import math


from exp.trainer_basic import Trainer_Basic
from utils.tools import EarlyStopping
from utils.dtw_metric import dtw,accelerated_dtw
from utils.tools import EarlyStopping, adjust_learning_rate, visual
from utils.metrics import metric
from data_provider.create_dataloader import data_provider_forecast
import warnings
warnings.filterwarnings('ignore')
def inverse_transform_torch(x, dataset):

    if hasattr(dataset, 'scaler') and hasattr(dataset.scaler, 'mean_') and hasattr(dataset.scaler, 'scale_'):
        mean = torch.as_tensor(dataset.scaler.mean_, dtype=x.dtype, device=x.device)   # [D]
        std  = torch.as_tensor(dataset.scaler.scale_, dtype=x.dtype, device=x.device)  # [D]
        while mean.ndim < x.ndim: mean = mean.unsqueeze(0)
        while std.ndim  < x.ndim: std  = std.unsqueeze(0)
        return x * std + mean

    # MinMaxScaler: x_norm = (x - min)/(max-min) -> x = x_norm*(max-min) + min
    if hasattr(dataset, 'scaler') and hasattr(dataset.scaler, 'data_min_') and hasattr(dataset.scaler, 'data_max_'):
        data_min = torch.as_tensor(dataset.scaler.data_min_, dtype=x.dtype, device=x.device)
        data_max = torch.as_tensor(dataset.scaler.data_max_, dtype=x.dtype, device=x.device)
        scale = data_max - data_min
        while data_min.ndim < x.ndim: data_min = data_min.unsqueeze(0)
        while scale.ndim    < x.ndim: scale    = scale.unsqueeze(0)
        return x * scale + data_min

    if hasattr(dataset, 'mean') and hasattr(dataset, 'std'):
        mean = torch.as_tensor(dataset.mean, dtype=x.dtype, device=x.device)
        std  = torch.as_tensor(dataset.std,  dtype=x.dtype, device=x.device)
        while mean.ndim < x.ndim: mean = mean.unsqueeze(0)
        while std.ndim  < x.ndim: std  = std.unsqueeze(0)
        return x * std + mean

    return x



class Trainer_Forecasting(Trainer_Basic):
    def __init__(self, args, df_raw):
        super(Trainer_Forecasting, self).__init__(args)
        self.df_raw = df_raw
        
    def _build_model(self):
        model = self.model_dict[self.args.model].Model(self.args).float()

        if self.args.use_multi_gpu and self.args.use_gpu:
            model = nn.DataParallel(model, device_ids=self.args.device_ids)
        return model
    
    def _get_data(self, flag):
        data_set, data_loader = data_provider_forecast(self.args, self.df_raw, flag)
        return data_set, data_loader
        

    def _select_criterion(self):
        smooth_l1 = nn.SmoothL1Loss(reduction='mean')
    
        def band_hinge_loss(pred, true, band=0.05):
            err = (pred - true).abs() - band
            return torch.relu(err).mean()
    
        def combined_loss(pred, true):
            return 0.5 * smooth_l1(pred, true) + 0.5 * band_hinge_loss(pred, true, band=0.05)
    
        class _Wrapper(nn.Module):
            def forward(self, pred, true):
                return combined_loss(pred, true)
    
        return _Wrapper()
    
    def _select_optimizer(self):
        wd = getattr(self.args, 'weight_decay', 1e-4)
        lr = getattr(self.args, 'learning_rate', getattr(self.args, 'lr', 1e-3))
        return torch.optim.AdamW(self.model.parameters(), lr=lr, weight_decay=wd)
    
    def _select_lr_scheduler(self, optimizer):
    
        total_epochs = int(getattr(self.args, 'train_epochs', 10))
        warmup_epochs = max(1, int(0.1 * total_epochs))
        base_lr = optimizer.param_groups[0]['lr']
        min_lr = base_lr * 0.01
    
        class _WarmupCosine:
            def __init__(self, opt):
                self.opt = opt
                self.last_epoch = 0
            def _set_lr(self, lr):
                for g in self.opt.param_groups:
                    g['lr'] = lr
            def step(self, *args, **kwargs):
                self.last_epoch += 1
                t = self.last_epoch
                if t <= warmup_epochs:
                    lr = base_lr * t / warmup_epochs
                else:
                    progress = (t - warmup_epochs) / max(1, total_epochs - warmup_epochs)
                    lr = min_lr + 0.5 * (base_lr - min_lr) * (1 + math.cos(math.pi * progress))
                self._set_lr(lr)
    
        return _WarmupCosine(optimizer)
    
    def _select_lr_scheduler(self, optimizer):
        total_epochs  = int(getattr(self.args, 'train_epochs', 10))
        warmup_epochs = max(1, int(0.1 * total_epochs))
        base_lr = optimizer.param_groups[0]['lr']
        min_lr  = base_lr * 0.01
    
        class _WarmupCosine:
            def __init__(self, opt):
                self.opt = opt
                self.last_epoch = 0
            def _set_lr(self, lr):
                for g in self.opt.param_groups:
                    g['lr'] = lr
            def step(self, *args, **kwargs):
                self.last_epoch += 1
                t = self.last_epoch
                if t <= warmup_epochs:
                    lr = base_lr * t / warmup_epochs
                else:
                    progress = (t - warmup_epochs) / max(1, total_epochs - warmup_epochs)
                    lr = min_lr + 0.5 * (base_lr - min_lr) * (1 + math.cos(math.pi * progress))
                self._set_lr(lr)
    
        return _WarmupCosine(optimizer)


    def train(self, setting):
        train_data, train_loader = self._get_data(flag='train')
        vali_data, vali_loader = self._get_data(flag='val')
        if self.args.test_ratio != 0.:
            test_data, test_loader = self._get_data(flag='test')
        
        path = os.path.join(self.args.checkpoints, setting)
        if not os.path.exists(path):
            os.makedirs(path)

        time_now = time.time()

        train_steps = len(train_loader)
        early_stopping = EarlyStopping(patience=self.args.patience, verbose=True)
        
        model_optim = self._select_optimizer()
        criterion = self._select_criterion()
        adjust_learning_rate = self._select_lr_scheduler(model_optim)
        
        
        if self.args.use_amp:
            scaler = torch.amp.GradScaler("cuda")
        
        # history
        history = {'train_loss_record': [],
                    'vali_loss_record': [],
                    'test_loss_record': []}
        if self.args.judgement is not None:
            history['vali_rate_record'] = []
            history['test_rate_record'] = []
        
        print('Training Start:')
        print(self.device)
        for epoch in range(self.args.train_epochs):
            print('--------------------------------------------------------------------------------------------')
            iter_count = 0
            train_loss = []
            
            self.model.train()
            epoch_time = time.time()
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
                iter_count += 1
                model_optim.zero_grad()
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)
                
                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)

                # encoder - decoder
                if self.args.use_amp:
                    with torch.amp.autocast("cuda"):
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)

                        f_dim = -1 if self.args.features == 'MS' else 0
                        outputs = outputs[:, -self.args.pred_len:, f_dim:]
                        batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)
                        loss = criterion(outputs, batch_y)
                        train_loss.append(loss.item())
                else:
                    outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)

                    f_dim = -1 if self.args.features == 'MS' else 0
                    outputs = outputs[:, -self.args.pred_len:, f_dim:]
                    batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)
                    loss = criterion(outputs, batch_y)
                    train_loss.append(loss.item())
                
                if (i + 1) % 100 == 0:
                    print("\titers: {0}, epoch: {1} | loss: {2:.7f}".format(i + 1, epoch + 1, loss.item()))
                    speed = (time.time() - time_now) / iter_count
                    left_time = speed * ((self.args.train_epochs - epoch) * train_steps - i)
                    print('\tspeed: {:.4f}s/iter; left time: {:.4f}s'.format(speed, left_time))
                    iter_count = 0
                    time_now = time.time()

                max_norm = 1.0
                if self.args.use_amp:
                    scaler.scale(loss).backward()
                    scaler.unscale_(model_optim)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm)
                    scaler.step(model_optim)
                    scaler.update()
                else:
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm)
                    model_optim.step()

            iter_count = 0
        
            print("Epoch: {} cost time: {}".format(epoch + 1, time.time() - epoch_time))
            train_loss = np.average(train_loss)
            vali_loss = self.vali(vali_loader, criterion, self.args.judgement)
            
            history['train_loss_record'].append(train_loss)
            history['vali_loss_record'].append(vali_loss)
            
            rate_info = ""
            if self.args.judgement is not None:
                vali_loss, vali_rate = vali_loss
                history['vali_rate_record'].append(vali_rate)
                if self.args.test_ratio != 0.:
                    test_loss, test_rate = test_loss
                    history['test_rate_record'].append(test_rate)
                    rate_info = " Vali Rate: {0:.7f} Test Rate: {1:.7f}".format(vali_rate, test_rate)
                else:
                    rate_info = " Vali Rate: {0:.7f}".format(vali_rate)
                
            if self.args.test_ratio != 0.:
                test_loss = self.vali(test_loader, criterion, self.args.judgement)
                history['test_loss_record'].append(test_loss)
                print("Epoch: {0}, Steps: {1} | Train Loss: {2:.7f} Vali Loss: {3:.7f} Test Loss: {4:.7f}{5}".format(
                    epoch + 1, train_steps, train_loss, vali_loss, test_loss, rate_info))
            else:
                print("Epoch: {0}, Steps: {1} | Train Loss: {2:.7f} Vali Loss: {3:.7f}{4}".format(
                    epoch + 1, train_steps, train_loss, vali_loss, rate_info))
                
            print("learning rate: ", model_optim.state_dict()['param_groups'][0]['lr'])
            # save model
            early_stopping(vali_loss, self.model, path)
            if early_stopping.early_stop:
                print("Early stopping")
                break
            
                    # adjust learning rate
            if self.args.lradj in ['type1', 'type2', 'type3']:
                adjust_learning_rate.step(epoch + 1)
            elif self.args.lradj == 'ReduceLROnPlateau':
                _vl = vali_loss[0] if isinstance(vali_loss, (tuple, list)) else vali_loss
                adjust_learning_rate.step(_vl)
            else:
                adjust_learning_rate.step()

        best_model_path = path + '/' + 'checkpoint.pth'
        self.model.load_state_dict(torch.load(best_model_path))
        torch.cuda.empty_cache()

        return self.model, history
    
    def vali(self, vali_loader, criterion, judgement=None):
        total_loss = []
        if judgement is not None:
            total_rate = []
            
        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(vali_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float()

                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)
                
                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)
                
                # encoder - decoder
                if self.args.use_amp:
                    with torch.amp.autocast("cuda"):
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
                else:
                    outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
                
                f_dim = -1 if self.args.features == 'MS' else 0
                outputs = outputs[:, -self.args.pred_len:, f_dim:]
                batch_y = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)
                
                # loss
                pred = outputs.detach().cpu()
                true = batch_y.detach().cpu()

                loss = criterion(pred, true)
                if judgement is not None:
                    rate = judgement.rate(pred, true)
                    total_rate.append(rate)
                
                total_loss.append(loss)
                
                
        total_loss = sum(total_loss) / len(total_loss)
        self.model.train()
        
        if judgement is not None:
            total_rate = np.average(total_rate)
            return total_loss, total_rate
        
        return total_loss
        
    def test(self, setting, test=0):
        test_data, test_loader = self._get_data(flag='test')
        if test:
            print('loading model')
            self.model.load_state_dict(torch.load(os.path.join('./checkpoints/' + setting, 'checkpoint.pth')))
    
        preds, trues = [], []
        folder_path = './test_results/' + setting + '/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
    
        seen_input_len = None
        stride = 1 
    
        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader):
                if seen_input_len is None:
                    seen_input_len = batch_x.shape[1]  # = input_len
    
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)
                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)
    
                # decoder input
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)
    
                # forward
                if self.args.use_amp:
                    with torch.amp.autocast("cuda"):
                        outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
                else:
                    outputs = self.model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
    
                f_dim = -1 if self.args.features == 'MS' else 0
                outputs = outputs[:, -self.args.pred_len:, :]
                batch_y = batch_y[:, -self.args.pred_len:, :].to(self.device)
    
                outputs = outputs.detach().cpu()
                batch_y = batch_y.detach().cpu()
    
                if test_data.scale and self.args.inverse:
                    outputs = inverse_transform_torch(outputs, test_data)  # [B, L, D]
                    batch_y = inverse_transform_torch(batch_y, test_data)  # [B, L, D]
    
                outputs = outputs[:, :, f_dim:]
                batch_y = batch_y[:, :, f_dim:]
    
                preds.append(outputs)   # list of [B, L, D]
                trues.append(batch_y)
    
                if i % 20 == 0 and self.args.test_plot:
                    inp = batch_x.detach().cpu()  # [B, L_in, D]
                    if test_data.scale and self.args.inverse:
                        inp = inverse_transform_torch(inp, test_data)
    
                    gt_series = torch.cat([inp[0, :, -1], batch_y[0, :, -1]], dim=0).tolist()
                    pd_series = torch.cat([inp[0, :, -1], outputs[0, :, -1]], dim=0).tolist()
                    visual(gt_series, pd_series, os.path.join(folder_path, f"{i}.pdf"))
    
        preds = torch.cat(preds, dim=0)   # [N, L, D]
        trues = torch.cat(trues, dim=0)   # [N, L, D]
        print('test shape:', preds.shape, trues.shape)
    
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        print('test shape:', preds.shape, trues.shape)
    
        base_dir = os.path.join('test_result', setting)
        os.makedirs(base_dir, exist_ok=True)
    
        def _save_tensor_csv(path, tensor_3d: torch.Tensor):
            t = tensor_3d.detach().cpu()
            N, L, D = t.shape
            with open(path, 'w', newline='') as f:
                w = csv.writer(f)
                header = ['sample', 'step'] + [f'var_{k}' for k in range(D)]
                w.writerow(header)
                for i in range(N):
                    for s in range(L):
                        row = [i, s] + [float(t[i, s, k]) for k in range(D)]
                        w.writerow(row)
    
        _save_tensor_csv(os.path.join(base_dir, 'pred.csv'), preds)
        _save_tensor_csv(os.path.join(base_dir, 'true.csv'), trues)
    
        diff = preds - trues  # [N, L, D]
        mae  = diff.abs().mean().item()
        mse  = torch.mean(diff ** 2).item()
        rmse = math.sqrt(mse)
        eps = 1e-8
        mape = (diff.abs() / (trues.abs() + eps)).mean().item()
        mspe = torch.mean(((diff) / (trues + eps)) ** 2).item()
    
        dtw = 'not calculated'
        if getattr(self.args, 'use_dtw', False):
            try:
                import numpy as np
                from fastdtw import fastdtw as accelerated_dtw
                dtw_list = []
                for i in range(preds.shape[0]):
                    x = preds[i].reshape(-1).detach().cpu().numpy()
                    y = trues[i].reshape(-1).detach().cpu().numpy()
                    if i % 100 == 0:
                        print("calculating dtw iter:", i)
                    d, _ = accelerated_dtw(x, y, dist=lambda a, b: abs(a - b))
                    dtw_list.append(d)
                dtw = float(np.mean(dtw_list))
            except Exception:
                pass
    
        print(f"mse:{mse}, mae:{mae}, rmse:{rmse}, mape:{mape}, mspe:{mspe}, dtw:{dtw}")
    
        with open(os.path.join(base_dir, 'results.csv'), 'w', newline='') as f:
            w = csv.writer(f)
            w.writerow(['metric', 'value'])
            w.writerow(['mae',  mae])
            w.writerow(['mse',  mse])
            w.writerow(['rmse', rmse])
            w.writerow(['mape', mape])
            w.writerow(['mspe', mspe])
            w.writerow(['dtw',  dtw])
    
        print("Results saved to:", base_dir)
    
        def _stitch_overlap_average(x_3d: torch.Tensor, input_len: int, pred_len: int, stride: int = 1) -> torch.Tensor:

            x_3d = x_3d.detach().cpu()
            N, P, D = x_3d.shape
            T = input_len + (N - 1) * stride + P
            sum_buf = torch.zeros(T, D, dtype=x_3d.dtype)
            cnt_buf = torch.zeros(T, D, dtype=x_3d.dtype)
            for ii in range(N):
                start = input_len + ii * stride
                sum_buf[start:start+P] += x_3d[ii]
                cnt_buf[start:start+P] += 1
            full = sum_buf / torch.clamp_min(cnt_buf, 1)
            return full  # [T, D]
        input_len_for_plot = seen_input_len if seen_input_len is not None else getattr(self.args, 'seq_len', 96) 
        pred_len_for_plot = preds.shape[1] 
        full_pred = _stitch_overlap_average(preds, input_len_for_plot, pred_len_for_plot, stride)# [T, D] 
        full_true = _stitch_overlap_average(trues, input_len_for_plot, pred_len_for_plot, stride) # [T, D]
    
        tol = 0.05
        x_axis = list(range(input_len_for_plot, input_len_for_plot + full_pred.shape[0]))
        
        y_true = full_true[:, -1]   # [T]
        y_pred = full_pred[:, -1]   # [T]
        
        low  = y_true - tol
        high = y_true + tol
        hit_mask = (y_pred >= low) & (y_pred <= high)
        hit_rate = hit_mask.float().mean().item()
        print(f"±{tol} band hit rate = {hit_rate:.4f}")
        
        plt.figure(figsize=(10, 4))
        plt.fill_between(
            x_axis,
            (y_true - tol).tolist(),
            (y_true + tol).tolist(),
            color='#E0E0E0',
            alpha=0.6,
            label=f'True ± {tol}'
        )

        plt.plot(x_axis, y_true.tolist(), label='True (stitched)', color='blue', linewidth=2)

        plt.plot(x_axis, y_pred.tolist(), label='Pred (stitched)', color='red', linewidth=2)
        
        plt.title(f"Full Prediction vs True (avg stitch) | input={input_len_for_plot}, pred={pred_len_for_plot}")
        plt.xlabel("Time")
        plt.ylabel("Value")
        plt.legend()
        svg_path = os.path.join(base_dir, 'all_pred_vs_true_band.svg')
        plt.savefig(svg_path, format='svg', bbox_inches='tight', dpi=300)
        plt.close()
        
        with open(os.path.join(base_dir, 'results.csv'), 'a', newline='') as f:
            w = csv.writer(f)
            w.writerow(['hit_rate_±0.05', hit_rate])

    
        torch.cuda.empty_cache()
    
        metrics = {'mae': mae, 'mse': mse, 'rmse': rmse, 'mape': mape, 'mspe': mspe, 'dtw': dtw}
        return preds, trues, full_pred, full_true, metrics, base_dir, svg_path
