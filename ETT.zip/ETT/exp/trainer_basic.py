import os
import torch
import torch.nn as nn
import torch.optim as optim
import torch_optimizer as opt
import torchmetrics as tm
from utils.tools import LrDecayCustomize
from models import Autoformer, Transformer, TimesNet, Nonstationary_Transformer, DLinear, FEDformer, \
    Informer, LightTS, Reformer, ETSformer, Pyraformer, PatchTST, MICN, Crossformer, FiLM, iTransformer, \
    Koopa, TiDE, FreTS, TimeMixer, TSMixer, TSTN, SegRNN, MambaSimple, TemporalFusionTransformer, SCINet, PAttn, \
    TimeXer, ModernTCN_forecasting, AD_MoE, GRU, oneD_CNN, LSTM, XGBoost


class Trainer_Basic(object):
    def __init__(self, args):
        self.args = args
        
        self.model_dict = {
            'TimesNet': TimesNet, 
            'Autoformer': Autoformer,
            'Transformer': Transformer,
            'Nonstationary_Transformer': Nonstationary_Transformer,
            'DLinear': DLinear, # good
            'FEDformer': FEDformer, # good
            'Informer': Informer,
            'LightTS': LightTS,
            'Reformer': Reformer,
            'ETSformer': ETSformer, # cpu
            'PatchTST': PatchTST,
            'Pyraformer': Pyraformer,
            'MICN': MICN,
            'Crossformer': Crossformer,
            'FiLM': FiLM,   # good
            'iTransformer': iTransformer,
            'Koopa': Koopa,
            'TiDE': TiDE,
            'FreTS': FreTS,
            'MambaSimple': MambaSimple,
            'TimeMixer': TimeMixer,  # 需要声明超参数 down_sampling_layers、down_sampling_window、down_sampling_method
            'TSMixer': TSMixer,
            'SegRNN': SegRNN,   # pred_len==seq_len if use SegRNN
            'TemporalFusionTransformer': TemporalFusionTransformer, # 如果使用 TemporalFusionTransformer，请确保在 TemporalFusionTransformer.py 中添加数据描述。
            "SCINet": SCINet,
            'PAttn': PAttn,
            'TimeXer': TimeXer,
            'ModernTCN_forecasting': ModernTCN_forecasting, # 需要声明独立超参数，详见 arguments.py 中 ModernTCN 部分,
            'TSTN': TSTN,
            'AD_MoE':AD_MoE,
            'GRU':GRU,
            'oneD_CNN':oneD_CNN,
            'LSTM':LSTM,
            'XGBoost':XGBoost
        }
        if args.model == 'Mamba':
            print('Please make sure you have successfully installed mamba_ssm')
            from models import Mamba
            self.model_dict['Mamba'] = Mamba
            
        self.device = self._acquire_device()
        self.model = self._build_model().to(self.device)

    def _acquire_device(self):
        if self.args.use_gpu and self.args.gpu_type == 'cuda':
            os.environ["CUDA_VISIBLE_DEVICES"] = str(
                self.args.gpu) if not self.args.use_multi_gpu else self.args.devices
            device = torch.device('cuda:{}'.format(self.args.gpu))
            print('Use GPU: cuda:{}'.format(self.args.gpu))
        elif self.args.use_gpu and self.args.gpu_type == 'mps':
            device = torch.device('mps')
            print('Use GPU: mps')
        else:
            device = torch.device('cpu')
            print('Use CPU')
        return device

    def _build_model(self):
        raise NotImplementedError
        return None

    def _select_criterion(self):
        if self.args.loss == 'MSE':
            criterion = nn.MSELoss()
        elif self.args.loss == 'L1':
            criterion = nn.L1Loss()
        elif self.args.loss == 'SMAPE':
            criterion = tm.SymmetricMeanAbsolutePercentageError().to(self.args.device)
        elif self.args.loss == 'MAPE':
            criterion = tm.MeanAbsolutePercentageError().to(self.args.device)
        elif self.args.loss == 'WMAPE':
            criterion = tm.WeightedMeanAbsolutePercentageError().to(self.args.device)
        elif self.args.loss == 'TDS':
            criterion = tm.TweedieDevianceScore().to(self.args.device)
        elif self.args.loss == 'CrossEntropyLoss':
            criterion = nn.CrossEntropyLoss()
        else:
            raise NotImplementedError

        return criterion

    def _select_optimizer(self):
        if self.args.optimizer == 'Adam':
            optimizer = optim.Adam(self.model.parameters(), lr=self.args.learning_rate, weight_decay=self.args.weight_decay)
        elif self.args.optimizer == 'AdamW':
            optimizer = optim.AdamW(self.model.parameters(), lr=self.args.learning_rate, weight_decay=self.args.weight_decay)
        elif self.args.optimizer == 'Yogi':
            optimizer = opt.Yogi(self.model.parameters(), lr=self.args.learning_rate, weight_decay=self.args.weight_decay)
        elif self.args.optimizer == 'SGD':
            optimizer = optim.SGD(self.model.parameters(), lr=self.args.learning_rate, weight_decay=self.args.weight_decay, momentum=self.args.momentum)
        elif self.args.optimizer == 'NAdam':
            optimizer = optim.NAdam(self.model.parameters(), lr=self.args.learning_rate, weight_decay=self.args.weight_decay)
        else:
            raise NotImplementedError
        return optimizer

    def _select_lr_scheduler(self, optimizer):
        if self.args.lradj in ['type1', 'type2', 'type3']:
            lr_decay = LrDecayCustomize(optimizer, self.args)
        elif self.args.lradj in ["StepLR",
                                 "MultiStepLR",
                                 "ExponentialLR",
                                 "LinearLR",
                                 "CosineAnnealingLR",
                                 "CosineAnnealingWarmRestarts",
                                 "LambdaLR",
                                 "MultiplicativeLR",
                                 "ConstantLR",
                                 "ReduceLROnPlateau"
                                 ]:
            if self.args.lradj == "StepLR":
                lr_decay = optim.lr_scheduler.StepLR(
                    optimizer,
                    step_size=self.args.lr_decay_step_size,
                    gamma=self.args.lr_decay_gamma,
                    verbose=self.args.lr_decay_verbose
                    )
            elif self.args.lradj == "MultiStepLR":
                lr_decay = optim.lr_scheduler.MultiStepLR(
                    optimizer, 
                    milestones=self.args.lr_decay_milestones,
                    gamma=self.args.lr_decay_gamma,
                    verbose=self.args.lr_decay_verbose
                    )
            elif self.args.lradj == "ExponentialLR":
                lr_decay = optim.lr_scheduler.ExponentialLR(
                    optimizer,
                    gamma=self.args.lr_decay_gamma,
                    verbose=self.args.lr_decay_verbose
                    )
            elif self.args.lradj == "LinearLR":
                lr_decay = optim.lr_scheduler.LinearLR(
                    optimizer,
                    start_factor=self.args.lr_decay_start_factor,
                    end_factor=self.args.lr_decay_end_factor,
                    total_iters=self.args.lr_decay_total_iters,
                    verbose=self.args.lr_decay_verbose
                    )
            elif self.args.lradj == 'CosineAnnealingLR':
                lr_decay = optim.lr_scheduler.CosineAnnealingLR(
                    optimizer,
                    T_max=self.args.lr_decay_T_max,
                    eta_min=self.args.lr_decay_min_lr,
                    verbose=self.args.lr_decay_verbose
                    )
            elif self.args.lradj == 'CosineAnnealingWarmRestarts':
                lr_decay = optim.lr_scheduler.CosineAnnealingWarmRestarts(
                    optimizer,
                    T_0=self.args.lr_decay_T_0,
                    T_mult=self.args.lr_decay_T_mult,
                    eta_min=self.args.lr_decay_min_lr,
                    verbose=self.args.lr_decay_verbose
                    )
            elif self.args.lradj == "LambdaLR":
                lr_decay = optim.lr_scheduler.LambdaLR(
                    optimizer,
                    lr_lambda=self.args.lr_decay_lambda,
                    verbose=self.args.lr_decay_verbose
                    )
            elif self.args.lradj == "MultiplicativeLR":
                lr_decay = optim.lr_scheduler.MultiplicativeLR(
                    optimizer,
                    lr_lambda=lambda epoch: self.args.lr_decay_factor,
                    verbose=self.args.lr_decay_verbose
                    )
            elif self.args.lradj == "ConstantLR":
                lr_decay = optim.lr_scheduler.ConstantLR(
                    optimizer, 
                    factor=self.args.lr_decay_factor,
                    total_iters=self.args.lr_decay_total_iters,
                    verbose=self.args.lr_decay_verbose
                    )
            elif self.args.lradj == "ReduceLROnPlateau":
                lr_decay = optim.lr_scheduler.ReduceLROnPlateau(
                    optimizer, 
                    mode=self.args.lr_decay_mode,
                    factor=self.args.lr_decay_factor,
                    patience=self.args.lr_decay_patience,
                    threshold=self.args.lr_decay_threshold,
                    threshold_mode =self.args.lr_decay_threshold_mode,
                    cooldown =self.args.lr_decay_cooldown,
                    min_lr=self.args.lr_decay_min_lr,
                    eps=self.args.lr_decay_eps,
                    verbose=self.args.lr_decay_verbose
                    )
        else:
            raise NotImplementedError
        return lr_decay
    
    def _get_data(self):
        pass
    
    def train(self):
        pass
    
    def vali(self):
        pass
    
    def test(self):
        pass
