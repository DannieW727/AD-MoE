import numpy as np
import tsmoothie.smoother as ts

def transform_data(data, x_len=5, y_len=5):

    # x = data
    # y = data
    X = np.array([data[i:(i+x_len)] for i in range(len(data)-x_len-y_len)])
    Y = np.array([data[(i+x_len):(i+x_len+y_len)] for i in range(len(data)-x_len-y_len)])

    return X, Y


def smooth_od(dataframe, column_list, component_noise={'level':1, 'trend':1}, observation_noise=1):

    for i in column_list:
        smoother = ts.KalmanSmoother(component='level_trend',
                                     component_noise = component_noise,
                                     observation_noise = observation_noise,)

        smoother.smooth(dataframe[i])
        low, up = smoother.get_intervals('kalman_interval')

        dataframe['smooth_data'] = smoother.smooth_data[0]
        dataframe['low'] = low[0]
        dataframe['up'] = up[0]

        dataframe['mask'] = (dataframe[i] > dataframe['low']) & (dataframe[i] < dataframe['up'])
        dataframe[i] = dataframe[i][dataframe['mask']]

    dataframe.drop(['smooth_data', 'mask', 'low', 'up'], axis=1, inplace=True)
