import torch
import torch.nn as nn

from .AD_MoE import (
    Model as ADMoEModel,
    AD_MoE_Backbone,
    EncoderLayer,
    DisentangledMixtureOfExperts,
    AdaptiveDilationAttention,
)

# --------------------------------------------------------------------- #
# Simple FFN（用于 No-MoE 替换 MoE）
# --------------------------------------------------------------------- #

class SimpleFFN(nn.Module):
    """Two-layer MLP to replace MoE in ablation (No-MoE)."""
    def __init__(self, d_model: int, dropout: float = 0.1, hidden_mul: int = 4):
        super().__init__()
        hidden = hidden_mul * d_model
        self.net = nn.Sequential(
            nn.Linear(d_model, hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, d_model),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)



class EncoderLayer_NoMoE(nn.Module):
    """
    Ablation A3: 第一子层保持 ADA，自适应膨胀注意力；
    第二子层改为 SimpleFFN（无 MoE）。
    """
    def __init__(self, d_model, n_heads, dilation_choices,
                 dropout=0.1, hidden_mul: int = 4):
        super().__init__()
        # ADA 子层
        self.ln1 = nn.LayerNorm(d_model)
        self.sa  = AdaptiveDilationAttention(
            d_model=d_model,
            n_heads=n_heads,
            dilation_choices=dilation_choices,
            dropout=dropout,
        )
        self.drop1 = nn.Dropout(dropout)

        # FFN 子层（用 SimpleFFN 替代 MoE）
        self.ln2 = nn.LayerNorm(d_model)
        self.ffn = SimpleFFN(
            d_model=d_model,
            dropout=dropout,
            hidden_mul=hidden_mul,
        )
        self.drop2 = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.drop1(self.sa(self.ln1(x)))
        x = x + self.drop2(self.ffn(self.ln2(x)))
        return x


class AD_MoE_Backbone_NoMoE(nn.Module):
    """
    继承原始设计思路：
    * Embedding + Sinusoidal PE 相同
    * 第一子层仍为 ADA
    * 第二子层全部换成 SimpleFFN（无 MoE）
    """
    def __init__(self, seq_len, in_dim, pred_len, d_model, n_layers, n_heads,
                 dilation_choices=(1, 2, 3, 4, 6, 8),
                 dropout=0.1, pooling='mean', per_var=False,
                 hidden_mul: int = 4):
        super().__init__()
        self.in_dim, self.pred_len = in_dim, pred_len

        self.embed = nn.Linear(in_dim, d_model)
        self.pe    = SinusoidalPE(d_model)

        self.layers = nn.ModuleList([
            EncoderLayer_NoMoE(
                d_model=d_model,
                n_heads=n_heads,
                dilation_choices=dilation_choices,
                dropout=dropout,
                hidden_mul=hidden_mul,
            )
            for _ in range(n_layers)
        ])

        if per_var:
            self.head = HorizonPerVarHead(
                d_model, in_dim, pred_len,
                pooling=pooling, dropout=dropout
            )
        else:
            self.head = HorizonSharedHead(
                d_model, in_dim, pred_len,
                pooling=pooling, dropout=dropout
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.embed(x)
        h = self.pe(h)
        for lyr in self.layers:
            h = lyr(h)

        delta = self.head(h)
        last = x[:, -1:, :].repeat(1, self.pred_len, 1)
        y = last + delta
        return y


class Model_NoMoE(ADMoEModel):
    """
    A3: No-MoE
    Backbone 保留自适应膨胀注意力（ADA），
    但 MoE 子层全部换成 SimpleFFN。
    """
    def __init__(self, configs, individual: bool = True):
        super().__init__(configs, individual)

        cfg = configs
        d_model  = getattr(cfg, 'd_model', 256)
        n_heads  = getattr(cfg, 'n_heads',
                           min(8, max(2, d_model // 32)))
        e_layers = getattr(cfg, 'e_layers', 3)
        dropout  = getattr(cfg, 'dropout', 0.2)
        dilate   = getattr(cfg, 'dilation_choices',
                           (1, 2, 3, 4, 6, 8))
        pooling  = getattr(cfg, 'pooling', 'attn')
        per_var  = bool(self.individual)
        hidden_mul = getattr(cfg, 'hidden_mul', 4)

        self.backbone = AD_MoE_Backbone_NoMoE(
            seq_len=self.seq_len,
            in_dim=self.enc_in,
            pred_len=self.pred_len,
            d_model=d_model,
            n_layers=e_layers,
            n_heads=n_heads,
            dilation_choices=dilate,
            dropout=dropout,
            pooling=pooling,
            per_var=per_var,
            hidden_mul=hidden_mul,
        )


# --------------------------------------------------------------------- #
# A1: Full — 原始 AD_MoE（直接复用你当前的 Model）
# --------------------------------------------------------------------- #

class Model_Full(ADMoEModel):
    """与当前 AD_MoE.Model 完全一致（Full 版本）。"""
    def __init__(self, configs, individual: bool = True):
        super().__init__(configs, individual)


# --------------------------------------------------------------------- #
# 统一工厂接口
# --------------------------------------------------------------------- #

def build_variant(name: str, configs):
    """
    name ∈ {'Full', 'No-Dilation', 'No-MoE'}（大小写/下划线不敏感）

    返回：nn.Module
        - forward 接口与原始 AD_MoE.Model 完全一致
        - 训练脚本 / Trainer 都不用改
    """
    key = str(name).lower()

    if key in ("full", "vanilla", "ad-moe", "ad_moe"):
        return Model_Full(configs, individual=getattr(configs, "individual", True))

    if key in ("no-dilation", "nodilation", "no_dilation"):
        return Model_NoDilation(configs, individual=getattr(configs, "individual", True))

    if key in ("no-moe", "nomoe", "no_moe"):
        return Model_NoMoE(configs, individual=getattr(configs, "individual", True))

    raise ValueError(
        f"Unknown ablation variant: {name!r}. "
        f"Allowed: 'Full', 'No-Dilation', 'No-MoE'."
    )


class Model_NoDilation(ADMoEModel):
    """
    Backbone 用无膨胀的注意力（dilation_choices = (1,)），
    其他结构（MoE、Head 等）与 Full 保持一致。
    """
    def __init__(self, configs, individual: bool = True):
        super().__init__(configs, individual)

        cfg = configs
        d_model  = getattr(cfg, 'd_model', 256)
        n_heads  = getattr(cfg, 'n_heads',
                           min(8, max(2, d_model // 32)))
        e_layers = getattr(cfg, 'e_layers', 3)
        dropout  = getattr(cfg, 'dropout', 0.2)
        num_exp  = getattr(cfg, 'num_experts', 3)
        top_k    = getattr(cfg, 'top_k', 1)
        pooling  = getattr(cfg, 'pooling', 'attn')
        per_var  = bool(self.individual)

        self.backbone = AD_MoE_Backbone(
            seq_len=self.seq_len,
            in_dim=self.enc_in,
            pred_len=self.pred_len,
            d_model=d_model,
            n_layers=e_layers,
            n_heads=n_heads,
            dilation_choices=(1,),     # ★ 核心：去掉多膨胀
            num_experts=num_exp,
            top_k=top_k,
            dropout=dropout,
            pooling=pooling,
            per_var=per_var,
        )
