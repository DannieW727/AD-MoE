import math
from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

try:
    from modules import AdaptiveDilationAttention, DisentangledMixtureOfExperts
except Exception:
    class AdaptiveDilationAttention(nn.Module):
        def __init__(self, d_model: int, n_heads: int, dilation_choices, dropout: float = 0.1):
            super().__init__()
            self.d_model = d_model
            self.n_heads = n_heads
            self.dilation_choices = sorted(dilation_choices)  # 确保排序
            self.head_dim = d_model // n_heads

            # 更合理的初始化
            self.dilation_logits = nn.Parameter(torch.zeros(n_heads, len(dilation_choices)))

            # 线性投影
            self.w_q = nn.Linear(d_model, d_model)
            self.w_k = nn.Linear(d_model, d_model)
            self.w_v = nn.Linear(d_model, d_model)
            self.w_o = nn.Linear(d_model, d_model)

            # Xavier 初始化
            nn.init.xavier_uniform_(self.w_q.weight)
            nn.init.xavier_uniform_(self.w_k.weight)
            nn.init.xavier_uniform_(self.w_v.weight)

            self.dropout = nn.Dropout(dropout)
            self.attention_dropout = nn.Dropout(dropout)
            self.ln = nn.LayerNorm(d_model)

        def forward(self, x: Tensor) -> Tensor:
            residual = x  # 残差连接
            x_ln = self.ln(x)

            batch_size, seq_len, _ = x.shape

            # 线性投影
            Q = self.w_q(x_ln)
            K = self.w_k(x_ln)
            V = self.w_v(x_ln)

            # 重塑为多头
            Q = Q.view(batch_size, seq_len, self.n_heads, self.head_dim).transpose(1, 2)
            K = K.view(batch_size, seq_len, self.n_heads, self.head_dim).transpose(1, 2)
            V = V.view(batch_size, seq_len, self.n_heads, self.head_dim).transpose(1, 2)

            attention_outputs = []
            for head_idx in range(self.n_heads):
                # 选择膨胀率
                dilation_probs = F.softmax(self.dilation_logits[head_idx], dim=-1)
                dilation_rate = sum(p * d for p, d in zip(dilation_probs, self.dilation_choices))

                # 应用膨胀采样（只对 K, V）
                dilated_K = self.dilate_sequence(K[:, head_idx], dilation_rate)
                dilated_V = self.dilate_sequence(V[:, head_idx], dilation_rate)

                # 注意力计算
                attn_scores = torch.matmul(Q[:, head_idx], dilated_K.transpose(-2, -1))
                attn_scores = attn_scores / math.sqrt(self.head_dim)

                # 可选：因果 mask
                # attn_scores = self.apply_causal_mask(attn_scores)

                attn_weights = F.softmax(attn_scores, dim=-1)
                attn_weights = self.attention_dropout(attn_weights)

                head_output = torch.matmul(attn_weights, dilated_V)
                attention_outputs.append(head_output)

            # 合并多头
            multi_head_output = torch.stack(attention_outputs, dim=1)
            multi_head_output = multi_head_output.transpose(1, 2).contiguous()
            multi_head_output = multi_head_output.view(batch_size, seq_len, self.d_model)

            output = self.w_o(multi_head_output)
            output = self.dropout(output)

            # 残差连接
            return residual + output

        def dilate_sequence(self, x: Tensor, dilation_rate: float) -> Tensor:
            """
            对输入序列应用膨胀采样
            x: [batch_size, seq_len, head_dim]
            dilation_rate: 膨胀率（可以是浮点数）
            """
            batch_size, seq_len, head_dim = x.shape

            if dilation_rate <= 1.0:
                return x  # 不进行膨胀

            # 计算膨胀后的序列长度
            dilated_seq_len = max(1, int(seq_len / dilation_rate))

            # 创建采样索引
            indices = torch.linspace(0, seq_len - 1, dilated_seq_len, device=x.device)
            indices = indices.long()

            # 采样得到膨胀后的序列
            dilated_x = x[:, indices, :]
            return dilated_x

        def get_dilation_rates(self):
            """获取每个头实际使用的膨胀率"""
            dilation_rates = []
            for head_idx in range(self.n_heads):
                dilation_logits = self.dilation_rates[head_idx] * torch.tensor(self.dilation_choices)
                dilation_probs = F.softmax(dilation_logits, dim=-1)
                dilation_rate = sum(p * d for p, d in zip(dilation_probs, self.dilation_choices))
                dilation_rates.append(dilation_rate.item())
            return dilation_rates

    class DisentangledMixtureOfExperts(nn.Module):
        def __init__(self, d_model: int, num_experts: int = 2,  # 只用 2 个专家
                     hidden_mul: int = 4, dropout: float = 0.1):
            super().__init__()
            # 基础 FFN（保证性能下限）
            self.base_ffn = nn.Sequential(
                nn.Linear(d_model, d_model * hidden_mul),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(d_model * hidden_mul, d_model),
            )
            # MoE 作为残差增强
            self.moe_experts = nn.ModuleList([
                nn.Sequential(
                    nn.Linear(d_model, d_model * (hidden_mul // 2)),
                    nn.GELU(),
                    nn.Linear(d_model * (hidden_mul // 2), d_model),
                ) for _ in range(num_experts)
            ])
            self.router = nn.Linear(d_model, num_experts, bias=False)
            self.alpha = 0.3  # 残差权重

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            # 基础 FFN
            base_out = self.base_ffn(x)

            # MoE 残差
            logits = self.router(x)
            probs = F.softmax(logits, dim=-1)

            moe_out = torch.zeros_like(x)
            for i, expert in enumerate(self.moe_experts):
                w_i = probs[..., i].unsqueeze(-1)
                moe_out += w_i * expert(x)

            # 残差连接
            return base_out + self.alpha * moe_out


class SinusoidalPE(nn.Module):
    def __init__(self, d_model: int, max_len: int = 10000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div = torch.exp(torch.arange(0, d_model, 2, dtype=torch.float32) *
                        (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe.unsqueeze(0), persistent=False)

    def forward(self, x: Tensor) -> Tensor:
        return x + self.pe[:, :x.size(1)]


class EncoderLayer(nn.Module):
    def __init__(self, d_model, n_heads, dilation_choices, num_experts, top_k, dropout=0.1):
        super().__init__()
        self.ln1 = nn.LayerNorm(d_model)
        self.sa  = AdaptiveDilationAttention(d_model, n_heads, dilation_choices, dropout)
        self.drop1 = nn.Dropout(dropout)

        self.ln2 = nn.LayerNorm(d_model)
        self.moe = DisentangledMixtureOfExperts(d_model, num_experts, top_k, dropout)
        self.drop2 = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.drop1(self.sa(self.ln1(x)))
        x = x + self.drop2(self.moe(self.ln2(x)))
        return x


class HorizonSharedHead(nn.Module):
    def __init__(self, d_model: int, in_dim: int, pred_len: int,
                 pooling='mean', dropout: float = 0.1):
        super().__init__()
        self.pred_len, self.in_dim = pred_len, in_dim
        self.pooling = pooling
        self.ln = nn.LayerNorm(d_model)
        if pooling == 'attn':
            self.q = nn.Parameter(torch.randn(1, 1, d_model) * 0.02)
            self.attn = nn.MultiheadAttention(d_model, 1, dropout=dropout,
                                              batch_first=True)
        self.mlp = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, pred_len * in_dim),
        )

    def forward(self, h: Tensor) -> Tensor:
        if self.pooling == 'attn':
            B = h.size(0)
            q = self.q.expand(B, -1, -1)
            p, _ = self.attn(self.ln(q), self.ln(h), self.ln(h), need_weights=False)
            p = p.squeeze(1)
        else:
            p = h.mean(dim=1)
        y = self.mlp(self.ln(p)).view(h.size(0), self.pred_len, self.in_dim)
        return y  # delta


class HorizonPerVarHead(nn.Module):
    def __init__(self, d_model: int, in_dim: int, pred_len: int,
                 pooling='mean', dropout: float = 0.1):
        super().__init__()
        self.pred_len, self.in_dim = pred_len, in_dim
        self.pooling = pooling
        self.ln = nn.LayerNorm(d_model)
        if pooling == 'attn':
            self.q = nn.Parameter(torch.randn(1, 1, d_model) * 0.02)
            self.attn = nn.MultiheadAttention(d_model, 1, dropout=dropout,
                                              batch_first=True)
        self.layers = nn.ModuleList([
            nn.Sequential(
                nn.Linear(d_model, d_model),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(d_model, pred_len),
            ) for _ in range(in_dim)
        ])

    def forward(self, h: Tensor) -> Tensor:
        if self.pooling == 'attn':
            B = h.size(0)
            q = self.q.expand(B, -1, -1)
            p, _ = self.attn(self.ln(q), self.ln(h), self.ln(h), need_weights=False)
            p = p.squeeze(1)
        else:
            p = h.mean(dim=1)
        p = self.ln(p)
        outs = [layer(p).unsqueeze(-1) for layer in self.layers]
        return torch.cat(outs, dim=-1)  # delta


class AD_MoE_Backbone(nn.Module):
    def __init__(self, seq_len, in_dim, pred_len, d_model, n_layers, n_heads,
                 dilation_choices=(1, 2, 3, 4, 6, 8), num_experts=2, top_k=1,
                 dropout=0.1, pooling='mean', per_var=False):
        super().__init__()
        self.in_dim, self.pred_len = in_dim, pred_len

        self.embed = nn.Linear(in_dim, d_model)
        self.pe    = SinusoidalPE(d_model)
        self.layers = nn.ModuleList([
            EncoderLayer(d_model, n_heads, dilation_choices,
                         num_experts, top_k, dropout)
            for _ in range(n_layers)
        ])

        if per_var:
            self.head = HorizonPerVarHead(d_model, in_dim, pred_len,
                                          pooling=pooling, dropout=dropout)
        else:
            self.head = HorizonSharedHead(d_model, in_dim, pred_len,
                                          pooling=pooling, dropout=dropout)


    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.embed(x)
        h = self.pe(h)
        for lyr in self.layers:
            h = lyr(h)

        delta = self.head(h)  # [B, pred_len, D] 或 [B, L, D]

        last = x[:, -1:, :].repeat(1, self.pred_len, 1)
        y = last + delta
        return y


class Model(nn.Module):
    def __init__(self, configs, individual: bool = True):
        super().__init__()
        self.task_name = configs.task_name
        self.seq_len   = configs.seq_len
        self.pred_len  = configs.seq_len if self.task_name in [
            'classification', 'anomaly_detection', 'imputation'
        ] else configs.pred_len
        self.enc_in    = configs.enc_in
        self.individual = getattr(configs, 'individual', individual)

        d_model  = getattr(configs, 'd_model',  256)
        n_heads  = getattr(configs, 'n_heads',  min(8, max(2, d_model // 32)))
        e_layers = getattr(configs, 'e_layers', 3)
        dropout  = getattr(configs, 'dropout',  0.2)
        num_exp  = getattr(configs, 'num_experts', 3)
        top_k    = getattr(configs, 'top_k', 1)
        dilate   = getattr(configs, 'dilation_choices', (1, 2, 3, 4, 6, 8))
        pooling  = getattr(configs, 'pooling', 'attn')
        per_var  = bool(self.individual)

        self.backbone = AD_MoE_Backbone(
            seq_len=self.seq_len, in_dim=self.enc_in, pred_len=self.pred_len,
            d_model=d_model, n_layers=e_layers, n_heads=n_heads,
            dilation_choices=dilate, num_experts=num_exp, top_k=top_k,
            dropout=dropout, pooling=pooling, per_var=per_var
        )

        if self.task_name == 'classification':
            self.projection = nn.Linear(
                self.enc_in * self.seq_len,
                getattr(configs, 'num_class', 2)
            )

    def encoder(self, x: Tensor) -> Tensor:
        return self.backbone(x)

    def forecast(self, x_enc: Tensor) -> Tensor:
        return self.encoder(x_enc)

    def imputation(self, x_enc: Tensor) -> Tensor:
        return self.encoder(x_enc)

    def anomaly_detection(self, x_enc: Tensor) -> Tensor:
        return self.encoder(x_enc)

    def classification(self, x_enc: Tensor) -> Tensor:
        enc_out = self.encoder(x_enc)
        out = enc_out.reshape(enc_out.shape[0], -1)
        return self.projection(out)

    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None, mask=None):
        if self.task_name in ['long_term_forecast', 'short_term_forecast', 'forecast']:
            dec_out = self.forecast(x_enc)
            return dec_out[:, -self.pred_len:, :]
        if self.task_name == 'imputation':
            return self.imputation(x_enc)
        if self.task_name == 'anomaly_detection':
            return self.anomaly_detection(x_enc)
        if self.task_name == 'classification':
            return self.classification(x_enc)
        return None
