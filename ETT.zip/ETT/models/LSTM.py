import torch
import torch.nn as nn
import torch.nn.functional as F
# 与 DLinear 相同的签名（即使没用到，也照样接收）
from layers.Autoformer_EncDec import series_decomp


class Model(nn.Module):
    """
    LSTM 版本（IO & args 与 DLinear 完全一致）
    输入: x_enc [B, seq_len, D],  D = configs.enc_in
    预测: 输出 [B, pred_len, D]（分类/插值/异常检测时 pred_len 会被置为 seq_len）
    """

    def __init__(self, configs, individual: bool = False):
        super().__init__()
        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.seq_len if self.task_name in ['classification', 'anomaly_detection', 'imputation'] \
                        else configs.pred_len

        # 与 DLinear 保持同样的 args 接口
        self.decompsition = series_decomp(configs.moving_avg)
        self.individual = individual
        self.channels = configs.enc_in

        # ----- LSTM 编码器 -----
        # 不新增新超参：hidden_size = enc_in；层数尽量复用 e_layers（若存在）
        num_layers = getattr(configs, 'e_layers', 1)
        self.rnn = nn.LSTM(
            input_size=self.channels,
            hidden_size=self.channels,     # 保持 D 不变，便于后续投影到原通道
            num_layers=num_layers,
            batch_first=True,
            dropout=0.0 if num_layers == 1 else 0.1,
            bidirectional=False
        )

        # ----- 时间维线性映射 L -> pred_len（与 DLinear 相同设计/初始化）-----
        if self.individual:
            self.TimeLinear = nn.ModuleList()
            for _ in range(self.channels):
                layer = nn.Linear(self.seq_len, self.pred_len)
                # 与 DLinear 相同的均值初始化
                layer.weight = nn.Parameter((1 / self.seq_len) * torch.ones([self.pred_len, self.seq_len]))
                self.TimeLinear.append(layer)
        else:
            self.TimeLinear = nn.Linear(self.seq_len, self.pred_len)
            self.TimeLinear.weight = nn.Parameter((1 / self.seq_len) * torch.ones([self.pred_len, self.seq_len]))

        # ----- 分类头（与 DLinear 完全一致）-----
        if self.task_name == 'classification':
            self.projection = nn.Linear(self.channels * self.seq_len, configs.num_class)

    # 与 DLinear 对齐：encoder 返回 [B, pred_len, D]
    def encoder(self, x):
        """
        x: [B, L, D]
        1) 这里不强依赖分解；先 LSTM 编码得到 [B, L, D]
        2) 转为 [B, D, L] 后做时间维线性映射 L->pred_len（与 DLinear 相同思想）
        """
        # 可选：如果你想与 DLinear 的“分解 + 线性”更贴近，可以把 seasonal/trend 拼或相加再喂 LSTM；
        # 这里直接用原序列进入 LSTM，保持简单稳健（IO一致）。
        y, _ = self.rnn(x)            # [B, L, D]（hidden_size=enc_in）
        y = y.permute(0, 2, 1)        # [B, D, L]

        if self.individual:
            # 按通道分别做 L->pred_len
            outs = []
            for i in range(self.channels):
                outs.append(self.TimeLinear[i](y[:, i, :]))   # [B, pred_len]
            y = torch.stack(outs, dim=1)                      # [B, D, pred_len]
        else:
            y = self.TimeLinear(y)                            # [B, D, pred_len]

        return y.permute(0, 2, 1)     # [B, pred_len, D]

    def forecast(self, x_enc):
        return self.encoder(x_enc)     # [B, pred_len, D]

    def imputation(self, x_enc):
        # 由于 pred_len 在 __init__ 中已置为 seq_len，此处输出 [B, L, D]
        return self.encoder(x_enc)

    def anomaly_detection(self, x_enc):
        return self.encoder(x_enc)

    def classification(self, x_enc):
        # 先得到 [B, L, D]（pred_len==seq_len）
        enc_out = self.encoder(x_enc)              # [B, L, D]
        output = enc_out.reshape(enc_out.shape[0], -1)  # [B, L*D]
        output = self.projection(output)           # [B, num_class]
        return output

    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        if self.task_name in ['long_term_forecast', 'short_term_forecast', 'forecast']:
            dec_out = self.forecast(x_enc)
            return dec_out[:, -self.pred_len:, :]  # [B, L, D] 兼容 DLinear 的切片写法
        if self.task_name == 'imputation':
            return self.imputation(x_enc)          # [B, L, D]
        if self.task_name == 'anomaly_detection':
            return self.anomaly_detection(x_enc)   # [B, L, D]
        if self.task_name == 'classification':
            return self.classification(x_enc)      # [B, N]
        return None
