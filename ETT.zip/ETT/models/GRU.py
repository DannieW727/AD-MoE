import torch
import torch.nn as nn
import torch.nn.functional as F
from layers.Autoformer_EncDec import series_decomp


class Model(nn.Module):
    """
    GRU 版本（IO & args 与 DLinear 完全一致）
    输入:  x_enc [B, seq_len, D] (D = configs.enc_in)
    输出:  [B, pred_len, D]      （分类/插补/异常检测时 pred_len == seq_len）
    """
    def __init__(self, configs, individual: bool = False):
        super().__init__()
        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = (configs.seq_len if self.task_name in
                         ['classification', 'anomaly_detection', 'imputation']
                         else configs.pred_len)

        # 保持接口一致
        self.decompsition = series_decomp(configs.moving_avg)
        self.individual = individual
        self.channels = configs.enc_in

        # GRU 编码器
        num_layers = getattr(configs, 'e_layers', 1)
        self.rnn = nn.GRU(
            input_size=self.channels,
            hidden_size=self.channels,     # 不改变维度，方便直接输出 D 维
            num_layers=num_layers,
            batch_first=True,
            dropout=0.0 if num_layers == 1 else 0.1,
            bidirectional=False
        )

        # 时间维线性映射 L -> pred_len，与 DLinear 初始化方式一致
        if self.individual:
            self.TimeLinear = nn.ModuleList()
            for _ in range(self.channels):
                layer = nn.Linear(self.seq_len, self.pred_len)
                layer.weight = nn.Parameter(
                    (1 / self.seq_len) * torch.ones([self.pred_len, self.seq_len])
                )
                self.TimeLinear.append(layer)
        else:
            self.TimeLinear = nn.Linear(self.seq_len, self.pred_len)
            self.TimeLinear.weight = nn.Parameter(
                (1 / self.seq_len) * torch.ones([self.pred_len, self.seq_len])
            )

        # 分类头，与 DLinear 完全一致
        if self.task_name == 'classification':
            self.projection = nn.Linear(self.channels * self.seq_len, configs.num_class)

    # 与 DLinear 对齐的 encoder 输出: [B, pred_len, D]
    def encoder(self, x):
        """
        x: [B, L, D]
        1) 经 GRU 编码得到 [B, L, D]
        2) 转置后经 TimeLinear 做时间维变换 L->pred_len
        """
        y, _ = self.rnn(x)           # [B, L, D]
        y = y.permute(0, 2, 1)       # [B, D, L]

        if self.individual:
            outs = []
            for i in range(self.channels):
                outs.append(self.TimeLinear[i](y[:, i, :]))   # [B, pred_len]
            y = torch.stack(outs, dim=1)                      # [B, D, pred_len]
        else:
            y = self.TimeLinear(y)                            # [B, D, pred_len]

        return y.permute(0, 2, 1)     # [B, pred_len, D]

    def forecast(self, x_enc):
        return self.encoder(x_enc)     # [B, pred_len, D]

    def imputation(self, x_enc):
        return self.encoder(x_enc)     # [B, L(=pred_len), D]

    def anomaly_detection(self, x_enc):
        return self.encoder(x_enc)     # [B, L(=pred_len), D]

    def classification(self, x_enc):
        enc_out = self.encoder(x_enc)                # [B, L, D]
        output = enc_out.reshape(enc_out.shape[0], -1)  # [B, L*D]
        return self.projection(output)               # [B, num_class]

    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        if self.task_name in ['long_term_forecast', 'short_term_forecast', 'forecast']:
            dec_out = self.forecast(x_enc)
            return dec_out[:, -self.pred_len:, :]  # [B, L, D]
        if self.task_name == 'imputation':
            return self.imputation(x_enc)          # [B, L, D]
        if self.task_name == 'anomaly_detection':
            return self.anomaly_detection(x_enc)   # [B, L, D]
        if self.task_name == 'classification':
            return self.classification(x_enc)      # [B, N]
        return None
