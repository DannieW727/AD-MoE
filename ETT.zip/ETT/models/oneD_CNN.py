import torch
import torch.nn as nn
import torch.nn.functional as F
from layers.Autoformer_EncDec import series_decomp


class ConvBlock(nn.Module):
    """简洁稳健的1D卷积残差块：Conv1d -> GELU -> Conv1d + 残差"""
    def __init__(self, channels, kernel_size=3, dilation=1):
        super().__init__()
        pad = (kernel_size - 1) // 2 * dilation
        self.conv1 = nn.Conv1d(channels, channels, kernel_size,
                               padding=pad, dilation=dilation)
        self.conv2 = nn.Conv1d(channels, channels, kernel_size,
                               padding=pad, dilation=dilation)
        self.act = nn.GELU()
        self.norm = nn.BatchNorm1d(channels)

    def forward(self, x):           # x: [B, C, L]
        y = self.conv1(x)
        y = self.act(self.norm(y))
        y = self.conv2(y)
        return self.act(y + x)      # 残差连接


class Model(nn.Module):
    """
    1D-CNN 版本（IO & args 与 DLinear 完全一致）
    输入:  x_enc [B, seq_len, D]  (D = configs.enc_in)
    输出:  [B, pred_len, D]       （分类/插值/异常检测时 pred_len==seq_len）
    """
    def __init__(self, configs, individual: bool = False):
        super().__init__()
        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = (configs.seq_len if self.task_name in
                         ['classification', 'anomaly_detection', 'imputation']
                         else configs.pred_len)

        # 与 DLinear 保持相同的 args 接口
        self.decompsition = series_decomp(configs.moving_avg)
        self.individual = individual
        self.channels = configs.enc_in

        # ----- 时间卷积编码器（保持通道数不变，便于后续映射）-----
        # 不新增新超参：层数固定为3层，使用逐层递增的膨胀率以覆盖多尺度依赖
        self.cnn = nn.Sequential(
            ConvBlock(self.channels, kernel_size=3, dilation=1),
            ConvBlock(self.channels, kernel_size=3, dilation=2),
            ConvBlock(self.channels, kernel_size=3, dilation=4),
        )

        # ----- 时间维线性映射 L -> pred_len（与 DLinear 相同设计/初始化）-----
        if self.individual:
            self.TimeLinear = nn.ModuleList()
            for _ in range(self.channels):
                layer = nn.Linear(self.seq_len, self.pred_len)
                layer.weight = nn.Parameter(
                    (1 / self.seq_len) * torch.ones([self.pred_len, self.seq_len])
                )
                self.TimeLinear.append(layer)
        else:
            self.TimeLinear = nn.Linear(self.seq_len, self.pred_len)
            self.TimeLinear.weight = nn.Parameter(
                (1 / self.seq_len) * torch.ones([self.pred_len, self.seq_len])
            )

        # ----- 分类头（与 DLinear 完全一致）-----
        if self.task_name == 'classification':
            self.projection = nn.Linear(self.channels * self.seq_len, configs.num_class)

    # 与 DLinear 对齐：返回 [B, pred_len, D]
    def encoder(self, x):
        """
        x: [B, L, D]
        1) 转为 [B, D, L] 做时间卷积
        2) 仍保持长度 L（padding 已对齐），然后做时间维线性映射 L->pred_len
        """
        # 可选：如需贴近 DLinear 的“分解+线性”，可以先 seasonal/trend 相加再卷积；
        # 这里直接对原序列做卷积，保证稳健简单。
        y = x.permute(0, 2, 1)        # [B, D, L]
        y = self.cnn(y)               # [B, D, L]

        if self.individual:
            outs = []
            for i in range(self.channels):
                outs.append(self.TimeLinear[i](y[:, i, :]))   # [B, pred_len]
            y = torch.stack(outs, dim=1)                      # [B, D, pred_len]
        else:
            y = self.TimeLinear(y)                            # [B, D, pred_len]

        return y.permute(0, 2, 1)     # [B, pred_len, D]

    def forecast(self, x_enc):
        return self.encoder(x_enc)     # [B, pred_len, D]

    def imputation(self, x_enc):
        return self.encoder(x_enc)     # [B, L(=pred_len), D]

    def anomaly_detection(self, x_enc):
        return self.encoder(x_enc)     # [B, L(=pred_len), D]

    def classification(self, x_enc):
        enc_out = self.encoder(x_enc)              # [B, L, D] (pred_len==seq_len)
        output = enc_out.reshape(enc_out.shape[0], -1)  # [B, L*D]
        return self.projection(output)             # [B, num_class]

    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        if self.task_name in ['long_term_forecast', 'short_term_forecast', 'forecast']:
            dec_out = self.forecast(x_enc)
            return dec_out[:, -self.pred_len:, :]  # [B, L, D]（与 DLinear 的切片保持一致）
        if self.task_name == 'imputation':
            return self.imputation(x_enc)          # [B, L, D]
        if self.task_name == 'anomaly_detection':
            return self.anomaly_detection(x_enc)   # [B, L, D]
        if self.task_name == 'classification':
            return self.classification(x_enc)      # [B, N]
        return None
