import torch
import torch.nn as nn
import numpy as np
import xgboost as xgb
from layers.Autoformer_EncDec import series_decomp


class Model(nn.Module):
    """
    XGBoost 版本（args/IO 与 DLinear 保持一致）
    训练：调用 fit_forecast / fit_imputation / fit_anomaly / fit_classification
    推理：forward()（需先训练）
    """
    def __init__(self, configs, individual: bool = False):
        super().__init__()
        # ---- 基本 args 对齐 ----
        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = (configs.seq_len if self.task_name in
                         ['classification', 'anomaly_detection', 'imputation']
                         else configs.pred_len)
        self.decompsition = series_decomp(configs.moving_avg)  # 不强依赖，可选用
        self.individual = individual
        self.channels = configs.enc_in
        self.num_class = getattr(configs, 'num_class', None)

        # ---- 模型容器 ----
        # 回归任务：dict[(d, h)] -> XGBRegressor   （h 为 horizon 或 time-index）
        # 分类任务：单个 XGBClassifier
        self.regressors = {}
        self.classifier = None

        # 训练标记
        self.is_trained_forecast = False
        self.is_trained_impute = False
        self.is_trained_anomaly = False
        self.is_trained_clf = False

        # XGBoost 默认参数（可按需调）
        self.xgb_reg_params = dict(
            n_estimators=300,
            learning_rate=0.05,
            max_depth=6,
            subsample=0.9,
            colsample_bytree=0.9,
            tree_method="hist",
            n_jobs=0,
            random_state=2025
        )
        self.xgb_clf_params = dict(
            n_estimators=500,
            learning_rate=0.05,
            max_depth=6,
            subsample=0.9,
            colsample_bytree=0.9,
            tree_method="hist",
            n_jobs=0,
            random_state=2025,
            objective="multi:softprob",
            num_class=self.num_class if self.num_class is not None else 2
        )

    # ---------- 工具：构造特征 ----------
    def _build_features(self, X):  # X: [N, L, D] -> feat: [N, F]
        if self.individual:
            # individual=True 时，后续按通道逐个取用，这里返回原 X，不聚合
            return X
        else:
            # individual=False: 多变量，拼接所有通道作为特征
            N, L, D = X.shape
            return X.reshape(N, L * D)  # [N, L*D]

    # ---------- 训练：Forecast ----------
    def fit_forecast(self, x_train: torch.Tensor, y_train: torch.Tensor):
        """
        x_train: [N, L, D]
        y_train: [N, pred_len, D]
        训练 pred_len × D 个回归器：
          - individual=True: 每个通道特征=该通道的 L 历史
          - individual=False: 特征=全体通道拼接 (L*D)
        """
        X = x_train.detach().cpu().numpy()
        Y = y_train.detach().cpu().numpy()
        N, L, D = X.shape
        assert Y.shape == (N, self.pred_len, D)

        if self.individual:
            # 每个通道独立，用自身历史 [N, L] 作为特征
            for d in range(D):
                Xd = X[:, :, d]  # [N, L]
                for h in range(self.pred_len):
                    ydh = Y[:, h, d]  # [N]
                    model = xgb.XGBRegressor(**self.xgb_reg_params)
                    model.fit(Xd, ydh)
                    self.regressors[(d, h)] = model
        else:
            # 多变量：用全通道拼接 [N, L*D]
            Xall = self._build_features(X)  # [N, L*D]
            for d in range(D):
                for h in range(self.pred_len):
                    ydh = Y[:, h, d]
                    model = xgb.XGBRegressor(**self.xgb_reg_params)
                    model.fit(Xall, ydh)
                    self.regressors[(d, h)] = model

        self.is_trained_forecast = True

    # ---------- 训练：Imputation ----------
    def fit_imputation(self, x_train: torch.Tensor, y_train: torch.Tensor = None):
        """
        x_train: [N, L, D]
        y_train: [N, L, D]（若 None 则默认自监督重建 x_train）
        学习“位置 t 的值”作为目标：共 L × D 个回归器。
        """
        X = x_train.detach().cpu().numpy()
        Y = X if y_train is None else y_train.detach().cpu().numpy()
        N, L, D = X.shape
        assert Y.shape == (N, L, D)

        if self.individual:
            for d in range(D):
                Xd = X[:, :, d]  # [N, L]
                for t in range(L):
                    ydt = Y[:, t, d]  # [N]
                    model = xgb.XGBRegressor(**self.xgb_reg_params)
                    model.fit(Xd, ydt)
                    self.regressors[(d, t)] = model
        else:
            Xall = self._build_features(X)  # [N, L*D]
            for d in range(D):
                for t in range(L):
                    ydt = Y[:, t, d]
                    model = xgb.XGBRegressor(**self.xgb_reg_params)
                    model.fit(Xall, ydt)
                    self.regressors[(d, t)] = model

        self.is_trained_impute = True

    # ---------- 训练：Anomaly (重建式，和 imputation 相同) ----------
    def fit_anomaly(self, x_train: torch.Tensor):
        """
        用重建作为基线，推理时可用 (x - x_hat) 评估异常。
        """
        self.fit_imputation(x_train)
        self.is_trained_anomaly = True

    # ---------- 训练：Classification ----------
    def fit_classification(self, x_train: torch.Tensor, y_train: torch.Tensor):
        """
        x_train: [N, L, D]
        y_train: [N] (类别索引)
        """
        X = x_train.detach().cpu().numpy()
        y = y_train.detach().cpu().numpy().astype(int)
        Xall = self._build_features(X) if not self.individual else X.reshape(X.shape[0], -1)
        # 说明：分类统一使用“全通道拼接”作为特征；若强制 individual，可改为仅用每通道训练再投票。
        params = dict(self.xgb_clf_params)
        if self.num_class is not None:
            params['num_class'] = self.num_class
        self.classifier = xgb.XGBClassifier(**params)
        self.classifier.fit(Xall, y)
        self.is_trained_clf = True

    # ---------- 推理统一入口 ----------
    def encoder(self, x):
        """
        x: [B, L, D] -> [B, pred_len, D]  或分类时在 classification() 里处理
        """
        X = x.detach().cpu().numpy()
        B, L, D = X.shape

        if self.task_name in ['forecast', 'long_term_forecast', 'short_term_forecast']:
            assert self.is_trained_forecast, "Call fit_forecast(...) before forward."
            Yhat = np.zeros((B, self.pred_len, D), dtype=np.float32)
            if self.individual:
                for d in range(D):
                    Xd = X[:, :, d]  # [B, L]
                    for h in range(self.pred_len):
                        mdl = self.regressors[(d, h)]
                        Yhat[:, h, d] = mdl.predict(Xd)
            else:
                Xall = self._build_features(X)  # [B, L*D]
                for d in range(D):
                    for h in range(self.pred_len):
                        mdl = self.regressors[(d, h)]
                        Yhat[:, h, d] = mdl.predict(Xall)
            return torch.from_numpy(Yhat).to(x.device)

        elif self.task_name == 'imputation':
            assert self.is_trained_impute, "Call fit_imputation(...) before forward."
            Yhat = np.zeros((B, L, D), dtype=np.float32)
            if self.individual:
                for d in range(D):
                    Xd = X[:, :, d]
                    for t in range(L):
                        mdl = self.regressors[(d, t)]
                        Yhat[:, t, d] = mdl.predict(Xd)
            else:
                Xall = self._build_features(X)
                for d in range(D):
                    for t in range(L):
                        mdl = self.regressors[(d, t)]
                        Yhat[:, t, d] = mdl.predict(Xall)
            return torch.from_numpy(Yhat).to(x.device)

        elif self.task_name == 'anomaly_detection':
            # 与 imputation 相同地重建
            self.task_name = 'imputation'
            out = self.encoder(x)
            self.task_name = 'anomaly_detection'
            return out

        else:
            raise RuntimeError("encoder() is only for forecasting/imputation/anomaly.")

    def classification(self, x):
        """
        x: [B, L, D] -> [B, num_class]
        输出为“类对数概率”（便于与 torch 的交叉熵对齐，可直接当 logits 使用）
        """
        assert self.is_trained_clf, "Call fit_classification(...) before forward."
        X = x.detach().cpu().numpy()
        B, L, D = X.shape
        Xall = self._build_features(X) if not self.individual else X.reshape(B, -1)
        proba = self.classifier.predict_proba(Xall)  # [B, C]
        logits = np.log(np.maximum(proba, 1e-12)).astype(np.float32)
        return torch.from_numpy(logits).to(x.device)

    # ---------- PyTorch 接口对齐 ----------
    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None, mask=None):
        if self.task_name in ['long_term_forecast', 'short_term_forecast', 'forecast']:
            dec_out = self.encoder(x_enc)
            return dec_out[:, -self.pred_len:, :]  # [B, pred_len, D]
        if self.task_name == 'imputation':
            return self.encoder(x_enc)             # [B, L, D]
        if self.task_name == 'anomaly_detection':
            return self.encoder(x_enc)             # [B, L, D]（重建）
        if self.task_name == 'classification':
            return self.classification(x_enc)      # [B, num_class]
        return None
