from data_provider.create_dataset import Forecast_Dataset_Creater
from torch.utils.data import DataLoader
import torch

def data_provider_forecast(args, df_raw, flag):
    
    timeenc = 0 if args.embed != 'timeF' else 1
    shuffle_flag = True if (flag == 'train' or flag == 'TRAIN') else False
    drop_last = True if (flag == 'train' or flag == 'TRAIN') else False
    batch_size = args.batch_size
    freq = args.freq
    
    data_set = Forecast_Dataset_Creater(
        args,
        df_raw,
        flag=flag,
        size=[args.seq_len, args.label_len, args.pred_len],
        features=args.features,
        target=args.target,
        timeenc=timeenc,
        freq=freq,
    )
    print(flag, len(data_set))
    data_loader = DataLoader(
        data_set,
        batch_size=batch_size,
        shuffle=shuffle_flag,
        num_workers=args.num_workers,
        drop_last=drop_last)
    return data_set, data_loader